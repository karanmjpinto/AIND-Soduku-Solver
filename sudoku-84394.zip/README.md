# Artificial Intelligence Nanodegree
## Introductory Project: Diagonal Sudoku Solver - Karan Pinto 

# Question 1 (Naked Twins)
Q: How do we use constraint propagation to solve the naked twins problem?  
A: 
Break Down:
The naked twins strategy is used together with the eliminate and only choice to simplify/reduce the puzzle and reduce the number of possibilities. 
The same constraint/restriction is then applied multiple times to arrive at a solution. This idea of refining a solution such that no further contraints can be applied to it,
is Constraint Propagation.

Strategy:
First, search for a pair of boxes with 2 same values in them, that are members of the same peer set. Then, search for and eliminate the values present in those specific boxes from the 
list of possibilities (boxes that by greater than 1 value only) in their peers. Technically, this can be executed using set intersection, examining each unit and checking for naked twins.
If a naked twin is present, the 2 digits are removed from other unsolved unit peers as no other box in the unit can have those 2 digits.

# Question 2 (Diagonal Sudoku)
Q: How do we use constraint propagation to solve the diagonal sudoku problem?  
A: Code the diagonals on the board and include it as a unit. The diagonals will then have peer and unit properties.
 Thus imposing constraints and reducing the possibilities on the board.
 





### Install

This project requires **Python 3**.

We recommend students install [Anaconda](https://www.continuum.io/downloads), a pre-packaged Python distribution that contains all of the necessary libraries and software for this project. 
Please try using the environment we provided in the Anaconda lesson of the Nanodegree.

##### Optional: Pygame

Optionally, you can also install pygame if you want to see your visualization. If you've followed our instructions for setting up our conda environment, you should be all set.

If not, please see how to download pygame [here](http://www.pygame.org/download.shtml).

### Code

* `solution.py` - You'll fill this in as part of your solution.
* `solution_test.py` - Do not modify this. You can test your solution by running `python solution_test.py`.
* `PySudoku.py` - Do not modify this. This is code for visualizing your solution.
* `visualize.py` - Do not modify this. This is code for visualizing your solution.

### Visualizing

To visualize your solution, please only assign values to the values_dict using the `assign_value` function provided in solution.py

### Submission
Before submitting your solution to a reviewer, you are required to submit your project to Udacity's Project Assistant, which will provide some initial feedback.  

The setup is simple.  If you have not installed the client tool already, then you may do so with the command `pip install udacity-pa`.  

To submit your code to the project assistant, run `udacity submit` from within the top-level directory of this project.  You will be prompted for a username and password.  If you login using google or facebook, visit [this link](https://project-assistant.udacity.com/auth_tokens/jwt_login) for alternate login instructions.

This process will create a zipfile in your top-level directory named sudoku-<id>.zip.  This is the file that you should submit to the Udacity reviews system.

